package com.example.chanjelajan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
