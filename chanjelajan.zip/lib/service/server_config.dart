class ServerConfig {
  static const String apiUrl = "https://api.apilayer.com/exchangerates_data/";
}
